#!/bin/bash

cd relay
make clean
make
./relay_main